<template lang="html">
  <div class="box">
    hello, blue -> {{a}}
    <Cmp1/>
  </div>
</template>

<script>
import Cmp1 from '@/components/Cmp1';

export default {
  data(){
    return {
      a: 12
    }
  },
  components: {
    Cmp1
  }
}
</script>

<style lang="css" scoped>
.box {width:200px; height:200px; background:#CCC;}
</style>
