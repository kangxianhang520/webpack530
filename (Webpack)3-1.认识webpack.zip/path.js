const path=require('path');

//console.log(path.resolve('aaa/bbb', '../ccc', './xxx/yyy', '../a.txt'));
console.log(path.resolve(__dirname, 'dest'));
