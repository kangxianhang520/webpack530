import $ from 'jquery';

$(function (){
  $('body').css('background', '#CCC');

  alert('aaa');

  console.log(process.env.NODE_ENV);
})
