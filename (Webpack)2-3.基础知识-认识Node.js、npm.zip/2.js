const Mod=require('./mod');

let obj=new Mod(99, 78);

console.log(obj.sum());
