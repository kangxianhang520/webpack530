module.exports={
  ESLINT: false,
  STYLELINT: false,
}
