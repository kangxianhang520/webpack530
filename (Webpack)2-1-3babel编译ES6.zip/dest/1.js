"use strict";

var a = 12;
var b = 5;

var sum = function sum(n1, n2) {
  return n1 + n2;
};

alert(sum(a, b));