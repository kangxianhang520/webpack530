let a=12;
let b=5;

let sum=(n1, n2)=>n1+n2;

alert(sum2(a, b));
