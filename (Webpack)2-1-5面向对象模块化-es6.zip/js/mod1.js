export let a=12;
export let b=5;
export let c=6;

//export default 99;

/*
let [a,b,c]=[12,5,8];

export {a,b,c};
*/
