//import * as mod1 from './mod1';
//import mod1 from './mod1';

//console.log(mod1);

//console.log(mod1.a, mod1.b, mod1.c);
//console.log(mod1);
let b=8;

import {a,b as name2} from './mod1';

console.log(a,b,name2);
